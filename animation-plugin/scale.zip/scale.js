com.hoperun.util.Animation.prototype.scale = function() {
	var self = this;
	if(self.getLastSlide() != null) self.getContainer().removeChild(self.getLastSlide().getDomInstance());
	var tempSlide = null;
	var i=0;
	function scale(){
		if(i++ < 20){
			window.setTimeout(scale, 50);
			self._resizeContainer(self.getContainer(), i/20);
			if(tempSlide!=null) self.getContainer().removeChild(tempSlide.getDomInstance());
			tempSlide = self.getSlide().clone();
			tempSlide.zoom(i/20);
			self.getContainer().appendChild(tempSlide.getDomInstance());
			self.setLastSlide(tempSlide);
		}
	}
	window.setTimeout(scale, 50);
	//self.setLastSlide(tempSlide);
}
