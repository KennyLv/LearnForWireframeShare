com.hoperun.util.Animation.prototype.alpha = function() {
	var self = this;
	if(self.getLastSlide() != null) self.getContainer().removeChild(self.getLastSlide().getDomInstance());
	var tempSlide = self.getSlide().clone();
	self._resizeContainer(self.getContainer(), 1);
	$(self.getContainer()).css({'opacity':0});
	self.getContainer().appendChild(tempSlide.getDomInstance());
	var i=0;
	function alpha(){
		if(i++ < 20){
			window.setTimeout(alpha, 50);
			$(self.getContainer()).css({'opacity':0.05*i});
		}
	}
	window.setTimeout(alpha, 50);
	self.setLastSlide(tempSlide);
}
