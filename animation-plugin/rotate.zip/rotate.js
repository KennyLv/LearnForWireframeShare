com.hoperun.util.Animation.prototype.rotate =  function() {
	var self = this;
	if(self.getLastSlide() != null) self.getContainer().removeChild(self.getLastSlide().getDomInstance());
	var tempSlide = self.getSlide().clone();
	self._resizeContainer(self.getContainer(), 1);
	self.getContainer().appendChild(tempSlide.getDomInstance());
	var i=0;
	var rotateVal = 0;
	function rotate(){
		if(i++ < 20){
			window.setTimeout(rotate, 50);
			rotateVal = i*18;
			$(self.getContainer()).css({
				'transform': 'rotate('+rotateVal+'deg)',
				'-o-transform': 'rotate('+rotateVal+'deg)',
				'-moz-transform': 'rotate('+rotateVal+'deg)',
				'-webkit-transform': 'rotate('+rotateVal+'deg)'
			}); 
		}
	}
	window.setTimeout(rotate, 50);
	self.setLastSlide(tempSlide);
}
