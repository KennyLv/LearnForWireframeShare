com.hoperun.util.Animation.prototype.none = function() {
	var self = this;
	if(self.getLastSlide() != null) self.getContainer().removeChild(self.getLastSlide().getDomInstance());
	var tempSlide = self.getSlide().clone();
	self._resizeContainer(self.getContainer(), 1);
	self.getContainer().appendChild(tempSlide.getDomInstance());
	self.setLastSlide(tempSlide);
}
