com.hoperun.util.Animation.prototype.translate = function() {
	var self = this;
	if(self.getLastSlide() != null) self.getContainer().removeChild(self.getLastSlide().getDomInstance());
	var tempSlide = self.getSlide().clone();
	$(self.getContainer()).css({"width":0, "height":770, "margin-right":($("body").width()-1366)/2});
	$(self.getContainer()).css({"margin-top":($('body').height()-$(self.getContainer()).height())/2});
	self.getContainer().appendChild(tempSlide.getDomInstance());
	var i=0;
	function translate(){
		if(i++ < 20){
			window.setTimeout(translate, 50);
			$(self.getContainer()).css({"width":1366*i/20});
		}else{
			$(self.getContainer()).css({"margin":'0 auto'});
			$(self.getContainer()).css({"margin-top":($('body').height()-$(self.getContainer()).height())/2});
		}
	}
	window.setTimeout(translate, 50);
	self.setLastSlide(tempSlide);
}
